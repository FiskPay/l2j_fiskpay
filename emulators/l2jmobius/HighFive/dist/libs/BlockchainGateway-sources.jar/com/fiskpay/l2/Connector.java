/*
* Copyright (c) 2025 FiskPay
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
* IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
package com.fiskpay.l2;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;

/**
 * @author Scrab
 */
public class Connector
{
    private Socket _socket;
    private Interface _connector;
    
    public Connector(Interface connector)
    {
        _connector = connector;
        
        try
        {
            IO.Options socketOptions = new IO.Options();
            
            // Transport Protocol Settings
            socketOptions.transports = new String[]
            {
                "websocket"
            };
            socketOptions.upgrade = false;
            
            // Reconnection Strategy
            socketOptions.reconnection = true;
            socketOptions.reconnectionDelay = 5000; // in milliseconds
            socketOptions.reconnectionAttempts = Integer.MAX_VALUE;
            socketOptions.randomizationFactor = 0.5;
            
            _socket = IO.socket("wss://ds.fiskpay.com:42099", socketOptions);
            
            Runtime.getRuntime().addShutdownHook(new Thread(() ->
            {
                _socket.disconnect();
                _socket.close();
            }));
            
            _socket.on("logDeposit", (args) ->
            {
                if (args.length == 6)
                {
                    String txHash = (String) args[0];
                    String from = (String) args[1];
                    String symbol = (String) args[2];
                    String amount = (String) args[3];
                    String server = (String) args[4];
                    String character = (String) args[5];
                    
                    _connector.onLogDeposit(txHash, from, symbol, amount, server, character);
                }
            });
            
            _socket.on("logWithdrawal", (args) ->
            {
                if (args.length == 7)
                {
                    String txHash = (String) args[0];
                    String to = (String) args[1];
                    String symbol = (String) args[2];
                    String amount = (String) args[3];
                    String server = (String) args[4];
                    String character = (String) args[5];
                    String refund = (String) args[6];
                    
                    _connector.onLogWithdraw(txHash, to, symbol, amount, server, character, refund);
                }
            });
            
            _socket.on("connect", (_) ->
            {
                _connector.onConnect();
            });
            
            _socket.on("disconnect", (_) ->
            {
                _connector.onDisconnect();
            });
            
            _socket.on("request", (args) ->
            {
                if (args.length == 2)
                {
                    JSONObject requestObject = (JSONObject) args[0];
                    Ack ack = (Ack) args[1];
                    
                    _connector.onRequest(requestObject, (responseObject) ->
                    {
                        ack.call(responseObject);
                    });
                }
            });
            
            _socket.connect();
        }
        catch (Exception e)
        {
            _connector.onError(e);
        }
    }
    
    public CompletableFuture<JSONObject> login(String tokenSymbol, String clientWalletAddress, String clientPassword, String signerAddress, JSONArray onlineServers)
    {
        CompletableFuture<JSONObject> future = new CompletableFuture<>();
        JSONObject sendObject = new JSONObject();
        
        sendObject.put("symbol", tokenSymbol);
        sendObject.put("wallet", clientWalletAddress);
        sendObject.put("password", clientPassword);
        sendObject.put("signerAddress", signerAddress);
        sendObject.put("servers", onlineServers);
        
        _socket.emit("login", sendObject, new Ack()
        {
            @Override
            public void call(Object... response)
            {
                try
                {
                    JSONObject responseObject = (JSONObject) response[0];
                    
                    future.complete(responseObject);
                }
                catch (Exception e)
                {
                    future.completeExceptionally(e);
                }
            }
        });
        
        return future.completeOnTimeout(new JSONObject().put("ok", false).put("error", "Login request timed out"), 5, TimeUnit.SECONDS).exceptionally(e -> new JSONObject().put("ok", false).put("error", e.getMessage()));
    }
    
    public void renewServers(JSONArray onlineServers)
    {
        _socket.emit("renewServers", onlineServers);
    }
    
    public interface Interface
    {
        void onLogDeposit(String txHash, String from, String symbol, String amount, String server, String character);
        
        void onLogWithdraw(String txHash, String to, String symbol, String amount, String server, String character, String refund);
        
        void onRequest(JSONObject requestObject, Callback cb);
        
        void onConnect();
        
        void onDisconnect();
        
        void onError(Exception e);
        
        @FunctionalInterface
        interface Callback
        {
            void resolve(JSONObject callbackObject);
        }
    }
}
