package com.fiskpay.l2;

public class Test {

    // java -cp "build;lib/*" com.fiskpay.l2.Test
    public static void main(String[] args) {

    }
}
